# BackTrack — product page and manual

Static site for the BackTrack Android app: a manual with the screens explained, what PRO adds,
and the privacy policy that Google Play links to.

| File | What it is |
|---|---|
| `index.html` | Manual + product page (one page, anchored sections) |
| `privacy.html` | Privacy policy — this is the URL that goes into Play Console |
| `style.css` | All styling. Colours are taken from the app (`ui/theme/Color.kt`, TacticalPalette) |
| `set-site-url.py` | One-shot helper that rewrites the public address everywhere |
| `assets/` | App icon, JetBrains Mono (SIL OFL 1.1, same file as in the APK), screenshots |

No build step, no framework, no JavaScript. Open `index.html` in a browser and it works.

---

## Screenshots are generated, not taken by hand

    py tools/zrzuty_na_strone.py        # in the BackTrack repo, phone connected

The script sets the font scale, theme and position, drives the app through the debug simulator
and captures every screen the manual uses. Run it after any UI change and the manual is true
again — that is the whole point of it existing. It also means no personal tracks or home
coordinates end up on the website.

Screenshots are stored as WebP at 1080 px wide (the phone's own width); the page never shows
them wider than ~340 px, so they stay sharp on high-density screens.

## Callouts

Numbered dots are HTML, not baked into the images:

```html
<span class="pin" style="left:37%; top:62%">6</span>
```

Positions are percentages, so the image can be any size and the dots stay put. The captions
live in an `<ol class="legend">` next to the frame, in the same order. To check a dot actually
lands on the control it describes, render them onto the image rather than eyeballing the page.

## Deploying to GitHub Pages

Create an empty **public** repository called `backtrack-site` on github.com (no README, no
.gitignore — this folder already is a git repository), then:

```bash
git remote add origin https://github.com/<user>/backtrack-site.git
git push -u origin main
```

Then in the repository: **Settings → Pages → Source: Deploy from a branch → `main` / root**.
The site appears at `https://<user>.github.io/backtrack-site/` within a minute or two.

The absolute address is already set to `https://j1nek.github.io/backtrack-site/`. If the account
name differs, or the site later moves to its own domain, one command fixes every place it
appears — canonical, `og:url`, the social card, structured data, `robots.txt`, `sitemap.xml`:

```bash
py set-site-url.py https://<user>.github.io/backtrack-site/
```

Nothing else depends on it: every link and asset inside the pages is relative, so the site
renders correctly under any address even before that command is run.

Both URLs then go into Play Console:

- **Store listing → Website**: the page root
- **App content → Privacy policy**: `…/privacy.html`

## Keep in step with the app

- Prices and the PRO wording must match the paywall in the app, Settings and the map badge:
  *one payment, lifetime access*.
- The privacy policy must match the **Data safety** answers in Play Console exactly. Map tiles
  are the one network request the app makes; it is described in section 3.1.
- Map data is © OpenStreetMap contributors (ODbL). The attribution stays in the footer of both
  pages and on every screenshot that shows the map.
